/*
    This is a calculator created with C#/Windows Forms as an example software to be used for a research paper (komvuxarbete).
    It was designed and written (with some small frustrations, as is par for the course) by me, Simon.
    The program and comments are written in English, for the sake of some actual naming and coding praxis,
    but also so anyone can read and understand my code together with at least the abstract of my document if they don't know swedish.

    Pretty much all the code is commented so you can look at any specific part and it should
    have a comment that explains what is going on and what that specific part of the code does.

    Final words before i go, go hug your loved ones for me, thanks.
    You'll regret not doing it when they're gone.
	
	Also, bearnaise-sauce on pizza is pretty good. Don't let anyone tell you otherwise.

    // Simon
*/

// Import the System namespace for basic functionality
using System;

// Import the System.Data namespace, required for calculating the math
using System.Data;

// Import the System.Windows.Forms namespace for Windows Forms
using System.Windows.Forms;



// Declare the namespace for the application
namespace WFormsCalculator
{
    // Declare the Form1 class, which is inheriting from Form
    public partial class Form1 : Form
    {
        // Declares a double to store the result of calculations
        private double result = 0;

        // Declares a bool to track if an operation was performed or not
        private bool isOperationPerformed = false;

        // Constructor for the Form1 class
        public Form1()
        {
            // Initialize the form components (buttons etc.)
            InitializeComponent();
        }


        /*
            Event handler for button clicks.
            If any button is pressed, this code runs to see what should happen depending on what was pressed.
            For example, if you press "7" it sends that "7" here and eventually it ends up adding that "7" to the textbox.
        */
        private void button_Click(object sender, EventArgs e)
        {
            // Cast sender to Button to find value of clicked button
            Button button = (Button)sender;

            // If the button was "."
            if (button.Text == ".")
            {
                // Split the current text by operators to find what is on the right side of said operator
                string[] parts = textBox1.Text.Split(new char[] { '+', '-', '*', '/' }, StringSplitOptions.RemoveEmptyEntries);
                string lastPart = parts.Last();

                /*
                    If a "." is found
                    (This check works for both sides of the operator! If you try to add a "." to a number even before adding an operator,
                    the check finds the "last" part of the content, and since there is only one "part" the first one is also the last one,
                    thus preventing double ".." signs even on a single decimal number without an added operator.)

                    (Also i had no idea this was actually going to just work, i thought i would have to write another check to
                    fix the first "side" of the math. But sometimes you just get lucky, i guess!)
                */
                if (lastPart.Contains("."))
                {
                    // Do nothing (this prevents two ".." decimal dots next to each other which cause errors)
                    return;
                }

                // Otherwise, add the decimal point
                textBox1.Text += button.Text;
            }

            // If the text box contains "0" and a number button was clicked
            else if (textBox1.Text == "0" && button.Text != ".")
            {
                // Replace "0" with the clicked number
                textBox1.Text = button.Text;
            }
                
            // If neither of those things happen
            else
            {
                // Add the clicked button's text (what sign is on the button itself) to the textbox
                textBox1.Text += button.Text;
            }
        }

        // Method to calculate the numbers and return the answer
        private double evaluateExpression(string expression)
        {
            try
            {
                // Use DataTable.Compute to evaluate the expression
                object result = new DataTable().Compute(expression, "");

                // Convert the result to double using invariant culture to prevent issues with "," being used instead of "."
                return Convert.ToDouble(result, System.Globalization.CultureInfo.InvariantCulture);
            }

            // If something goes wrong
            catch (Exception ex)
            {
                // Show an error message
                throw new Exception("Invalid expression.", ex);
            }
        }

        // Event handler for when operator buttons are pressed
        private void operator_Click(object sender, EventArgs e)
        {
            // Cast sender to Button to get the value of said clicked button
            Button button = (Button)sender;

            // If an operation was already performed
            if (isOperationPerformed)
            {
                // Replace the last character with the new operator (prevents multiple operator signs in a row, which cause errors)
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1) + button.Text;
            }

            // If no operation was performed (no operator sign as last character)
            else
            {
                // Add the operator to the text box
                textBox1.Text += button.Text;
            }

            // Set the operation performed flag
            isOperationPerformed = true;
        }

        // When button "0" is clicked
        private void button0_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 0
            button_Click(sender, e);
        }

        // When button "1" is clicked
        private void button1_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 1
            button_Click(sender, e);
        }

        // When button "2" is clicked
        private void button2_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 2
            button_Click(sender, e);
        }

        // When button "3" is clicked
        private void button3_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 3
            button_Click(sender, e);
        }

        // When button "4" is clicked
        private void button4_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 4
            button_Click(sender, e);
        }

        // When button "5" is clicked
        private void button5_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 5
            button_Click(sender, e);
        }

        // When button "6" is clicked
        private void button6_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 6
            button_Click(sender, e);
        }

        // When button "7" is clicked
        private void button7_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 7
            button_Click(sender, e);
        }

        // When button "8" is clicked
        private void button8_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 8
            button_Click(sender, e);
        }

        // When button "9" is clicked
        private void button9_Click(object sender, EventArgs e)
        {
            // Call button_Click for button 9
            button_Click(sender, e);
        }

        // When button "." decimal is clicked
        private void buttonDecimal_Click(object sender, EventArgs e)
        {
            // Call button_Click for the decimal point button
            button_Click(sender, e);
        }

        // When button "/" division is clicked
        private void buttonDivision_Click(object sender, EventArgs e)
        {
            // Call operator_Click for division button
            operator_Click(sender, e);
        }

        // When button "*" multiplication is clicked
        private void buttonMultiply_Click(object sender, EventArgs e)
        {
            // Call operator_Click for multiplication button
            operator_Click(sender, e);
        }

        // When button "-" minus is clicked
        private void buttonMinus_Click(object sender, EventArgs e)
        {
            // Call operator_Click for subtraction button
            operator_Click(sender, e);
        }

        // When button "+" plus is clicked
        private void buttonPlus_Click(object sender, EventArgs e)
        {
            // Call operator_Click for addition button
            operator_Click(sender, e);
        }

        // When button "CLEAR" is clicked
        private void buttonClear_Click(object sender, EventArgs e)
        {
            // Reset the text box to "0"
            textBox1.Text = "0";

            // Reset the result
            result = 0;

            // Reset the operation performed flag
            isOperationPerformed = false;
        }

        // When button "=" equals is clicked
        private void buttonEquals_Click(object sender, EventArgs e)
        {
            try
            {
                // Evaluate the expression in the text box
                result = evaluateExpression(textBox1.Text);

                // Display the result in the text box using invariant culture to prevent issues with "," being used instead of "."
                textBox1.Text = result.ToString(System.Globalization.CultureInfo.InvariantCulture);

                // Reset the operation performed flag
                isOperationPerformed = false;
            }

            // If something goes wrong
            catch (Exception ex)
            {
                // Display "Error" in the text box
                textBox1.Text = "Error";

                // Show an error message
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
