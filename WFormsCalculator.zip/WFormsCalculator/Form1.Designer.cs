﻿namespace WFormsCalculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button0 = new Button();
            buttonDecimal = new Button();
            buttonEquals = new Button();
            buttonDivision = new Button();
            buttonMultiply = new Button();
            buttonMinus = new Button();
            buttonPlus = new Button();
            buttonClear = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // button7
            // 
            button7.Cursor = Cursors.Hand;
            button7.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.Location = new Point(12, 75);
            button7.Name = "button7";
            button7.Size = new Size(80, 80);
            button7.TabIndex = 7;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Cursor = Cursors.Hand;
            button8.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button8.Location = new Point(98, 75);
            button8.Name = "button8";
            button8.Size = new Size(80, 80);
            button8.TabIndex = 8;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Cursor = Cursors.Hand;
            button9.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button9.Location = new Point(184, 75);
            button9.Name = "button9";
            button9.Size = new Size(80, 80);
            button9.TabIndex = 9;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button4
            // 
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(12, 161);
            button4.Name = "button4";
            button4.Size = new Size(80, 80);
            button4.TabIndex = 4;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Cursor = Cursors.Hand;
            button5.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(98, 161);
            button5.Name = "button5";
            button5.Size = new Size(80, 80);
            button5.TabIndex = 5;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Cursor = Cursors.Hand;
            button6.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.Location = new Point(184, 161);
            button6.Name = "button6";
            button6.Size = new Size(80, 80);
            button6.TabIndex = 6;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(12, 247);
            button1.Name = "button1";
            button1.Size = new Size(80, 80);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(98, 247);
            button2.Name = "button2";
            button2.Size = new Size(80, 80);
            button2.TabIndex = 2;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(184, 247);
            button3.Name = "button3";
            button3.Size = new Size(80, 80);
            button3.TabIndex = 3;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button0
            // 
            button0.Cursor = Cursors.Hand;
            button0.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button0.Location = new Point(98, 333);
            button0.Name = "button0";
            button0.Size = new Size(80, 80);
            button0.TabIndex = 10;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = true;
            button0.Click += button0_Click;
            // 
            // buttonDecimal
            // 
            buttonDecimal.Cursor = Cursors.Hand;
            buttonDecimal.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonDecimal.Location = new Point(12, 333);
            buttonDecimal.Name = "buttonDecimal";
            buttonDecimal.Size = new Size(80, 80);
            buttonDecimal.TabIndex = 11;
            buttonDecimal.Text = ".";
            buttonDecimal.UseVisualStyleBackColor = true;
            buttonDecimal.Click += buttonDecimal_Click;
            // 
            // buttonEquals
            // 
            buttonEquals.Cursor = Cursors.Hand;
            buttonEquals.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonEquals.Location = new Point(184, 333);
            buttonEquals.Name = "buttonEquals";
            buttonEquals.Size = new Size(80, 80);
            buttonEquals.TabIndex = 12;
            buttonEquals.Text = "=";
            buttonEquals.UseVisualStyleBackColor = true;
            buttonEquals.Click += buttonEquals_Click;
            // 
            // buttonDivision
            // 
            buttonDivision.Cursor = Cursors.Hand;
            buttonDivision.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonDivision.Location = new Point(270, 75);
            buttonDivision.Name = "buttonDivision";
            buttonDivision.Size = new Size(80, 80);
            buttonDivision.TabIndex = 13;
            buttonDivision.Text = "/";
            buttonDivision.UseVisualStyleBackColor = true;
            buttonDivision.Click += buttonDivision_Click;
            // 
            // buttonMultiply
            // 
            buttonMultiply.Cursor = Cursors.Hand;
            buttonMultiply.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonMultiply.Location = new Point(270, 161);
            buttonMultiply.Name = "buttonMultiply";
            buttonMultiply.Size = new Size(80, 80);
            buttonMultiply.TabIndex = 14;
            buttonMultiply.Text = "*";
            buttonMultiply.UseVisualStyleBackColor = true;
            buttonMultiply.Click += buttonMultiply_Click;
            // 
            // buttonMinus
            // 
            buttonMinus.Cursor = Cursors.Hand;
            buttonMinus.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonMinus.Location = new Point(270, 247);
            buttonMinus.Name = "buttonMinus";
            buttonMinus.Size = new Size(80, 80);
            buttonMinus.TabIndex = 15;
            buttonMinus.Text = "-";
            buttonMinus.UseVisualStyleBackColor = true;
            buttonMinus.Click += buttonMinus_Click;
            // 
            // buttonPlus
            // 
            buttonPlus.Cursor = Cursors.Hand;
            buttonPlus.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonPlus.Location = new Point(270, 333);
            buttonPlus.Name = "buttonPlus";
            buttonPlus.Size = new Size(80, 80);
            buttonPlus.TabIndex = 16;
            buttonPlus.Text = "+";
            buttonPlus.UseVisualStyleBackColor = true;
            buttonPlus.Click += buttonPlus_Click;
            // 
            // buttonClear
            // 
            buttonClear.Cursor = Cursors.Hand;
            buttonClear.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonClear.Location = new Point(12, 419);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(338, 80);
            buttonClear.TabIndex = 17;
            buttonClear.Text = "CLEAR";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Cursor = Cursors.No;
            textBox1.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(12, 12);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(338, 57);
            textBox1.TabIndex = 18;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(362, 507);
            Controls.Add(textBox1);
            Controls.Add(buttonClear);
            Controls.Add(buttonPlus);
            Controls.Add(buttonMinus);
            Controls.Add(buttonMultiply);
            Controls.Add(buttonDivision);
            Controls.Add(buttonEquals);
            Controls.Add(buttonDecimal);
            Controls.Add(button0);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            ForeColor = Color.Black;
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "Form1";
            Text = "WForms Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button0;
        private Button buttonDecimal;
        private Button buttonEquals;
        private Button buttonDivision;
        private Button buttonMultiply;
        private Button buttonMinus;
        private Button buttonPlus;
        private Button buttonClear;
        private TextBox textBox1;
    }
}
