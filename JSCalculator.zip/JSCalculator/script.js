/*
	This is the JavaScript code stuff
	that does all the cool mathematics n' stuff
	
	Just like the rest of the source code in this repository,
	every line is commented, every comment explains the line below it.
	
	I took my first motorcycle trip of 2024 yesterday,
	and if i could program that feeling of freedom into
	this JavaScript code, i would.
	
	Final words, stay safe out there, be it in a car or on a superior two-wheeler!
	// Simon
*/

// Retrieve the element with id display and store it in the variable display
let display = document.getElementById('display');

// Looks at what sign belongs to the button that was pressed and adds it to "display.value"
function append(value)
{
  display.value += value;
}

// Clears display by setting it's value to nothing
function clearDisplay()
{
  display.value = '';
}

// Looks at what is in display and calculates the answer
function calculate()
{
  try
  {
    // Uses eval() to calculate the answer to what is in display and once calculated replaces the content of display with the answer
    display.value = eval(display.value);
  }
  
  // If something goes wrong
  catch (error)
  {
    // If an error occurs during calculation, display 'Error' in the display
    display.value = 'Error';
  }
}
